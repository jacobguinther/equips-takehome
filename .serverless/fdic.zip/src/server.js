"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
var server_1 = require("@apollo/server");
var aws_lambda_1 = require("@as-integrations/aws-lambda");
var axios_1 = require("axios");
// The GraphQL schema
var typeDefs = "#graphql\n    type Institution {\n                ZIP: String\n                SASSER: Int\n                CHRTAGNT: String\n                CONSERVE: String\n                REGAGENT2: String\n                STNAME: String\n                INSDATE: String\n                TE06N528: String\n                TE06N529: String\n                FDICDBS: Int\n                OCCDIST: String\n                CMSA: String\n                CBSA_METRO_FLG: String\n                TE10N528: String\n                CBSA_DIV_NO: String\n                MSA_NO: String\n                INSSAVE: Int\n                CHARTER: String\n                TE04N528: String\n                TE04N529: String\n                CERT: Int\n                STALP: String\n                CFPBENDDTE: String\n                TE09N528: String\n                IBA: Int\n                INSBIF: Int\n                INSFDIC: Int\n                ENDEFYMD: String\n                MSA: String\n                TE02N528: String\n                TE02N529: String\n                TE07N528: String\n                FDICSUPV:String\n                FED: String\n                REGAGNT: String\n                NEWCERT: Int\n                CBSA_MICRO_FLG: String\n                STCNTY: String\n                CSA_FLG: String\n                CITY: String\n                CLCODE: String\n                INACTIVE: Int\n                CMSA_NO: String\n                INSAGNT1: String\n                BKCLASS: String\n                EFFDATE: String\n                SUPRV_FD: String\n                DATEUPDT: String\n                INSAGNT2: String\n                TE05N528: String\n                TE05N529: String\n                FDICREGN: String\n                FLDOFF: String\n                WEBADDR: String\n                QBPRCOML: String\n                COUNTY: String\n                DOCKET: String\n                ULTCERT: String\n                OTSDIST: String\n                LAW_SASSER_FLG: String\n                CFPBFLAG: Int\n                RISDATE: String\n                INSCOML: Int\n                OCCDISTDESC: String\n                OTSREGNM: String\n                RUNDATE: String\n                TE03N528: String\n                TE03N529: String\n                NAME: String\n                MDI_STATUS_DESC: String\n                CBSA_DIV: String\n                ADDRESS: String\n                LATITUDE: Float\n                PROCDATE: String\n                INSSAIF: Int\n                CBSA_NO: String\n                ACTIVE: Int\n                CBSA_METRO_NAME: String\n                CFPBEFFDTE: String\n                STCHRTR: Int\n                LONGITUDE: Float\n                MDI_STATUS_CODE: String\n                CSA: String\n                INSDIF: Int\n                TE01N529: String\n                OI: Int\n                STNUM: String\n                OAKAR: Int\n                ADDRESS2: String\n                PRIORNAME1: String\n                FEDDESC: String\n                FED_RSSD: String\n                CSA_NO: String\n                CBSA_METRO: String\n                UNINUM: String\n                TE01N528: String\n                CBSA: String\n                CBSA_DIV_FLG: String\n                TE08N528: String\n                CHANGEC1: Int\n                ESTYMD: String\n                FEDCHRTR: Int\n                ID: String\n    }\n\n  type Query {\n    institutions: [Institution]\n  }\n";
// A map of functions which return data for the schema.
var resolvers = {
    Query: {
        institutions: function () { return __awaiter(void 0, void 0, void 0, function () {
            var resp, institutions;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, axios_1.default
                            .get('https://banks.data.fdic.gov/api/institutions')];
                    case 1:
                        resp = _a.sent();
                        if (resp.status === 200) {
                            institutions = resp.data.data.map(function (institution) { return institution.data; });
                            return [2 /*return*/, institutions];
                        }
                        return [2 /*return*/];
                }
            });
        }); },
    },
};
// Set up Apollo Server
var server = new server_1.ApolloServer({
    typeDefs: typeDefs,
    resolvers: resolvers,
});
exports.graphqlHandler = (0, aws_lambda_1.startServerAndCreateLambdaHandler)(server, 
// We will be using the Proxy V2 handler
aws_lambda_1.handlers.createAPIGatewayProxyEventV2RequestHandler());
//# sourceMappingURL=server.js.map